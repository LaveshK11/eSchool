define({
  "name": "School Management",
  "version": "0.1.0",
  "description": "API Documentation for all the routes",
  "title": "API Documentation",
  "url": "http://localhost:8080/api/v1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2022-05-24T16:35:15.116Z",
    "url": "https://apidocjs.com",
    "version": "0.28.1"
  }
});
